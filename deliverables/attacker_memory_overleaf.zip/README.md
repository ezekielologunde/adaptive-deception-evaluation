# ACM manuscript and complete verification evidence

Compile main.tex in Overleaf with a current TeX Live distribution. The source is self-contained (acmart, TikZ, pgfplots). This is a completed bounded research draft, not a claim of journal acceptance or established algorithmic novelty.

Author: Ezekiel Ologunde, Independent Researcher, Boston, MA, USA; ologunde@bu.edu. Original work remains unlicensed. Third-party source checkouts and paper PDFs are not included.

validation.json contains automated and delivery checks. verification/repository contains full original simulation traces, frozen protocols, source hashes, analysis programs, manuscript template, and environment lock. Read its REPRODUCE.md. Run analysis using Python 3.10 and NumPy; acquire the pinned Cyberwheel source only if collecting new simulation worlds. The verification scripts are independently written checks, not an independent investigator's replication.

The PDF was built with a pinned isolated compiler; Overleaf's hosted environment itself was not tested. The research repository is https://github.com/ezekielologunde/adaptive-deception-evaluation .
